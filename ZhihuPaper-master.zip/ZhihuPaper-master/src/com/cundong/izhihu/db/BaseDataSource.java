package com.cundong.izhihu.db;

public class BaseDataSource {

}