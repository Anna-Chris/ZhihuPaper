cd /Users/cundong/Documents/github/iZhihuPaper
ant deploy
pause